# The Synthesizer’s Guide to Angel Investing – Landing Page

This repository contains a simple static landing page (`index.html`) and a PDF guide.

## Files

- `index.html` – the Notion‑style landing page (open in browser)
- `Synthesizers_Guide_to_Angel_Investing.pdf` – the full guide (linked from the page)

## How to Deploy on GitHub Pages

1. **Create a GitHub account** (if you don’t have one yet) at [https://github.com](https://github.com).

2. **Create a new repository**:  
   - Go to your GitHub profile → “Repositories” → “New”.  
   - Name it something like `synthesizer-guide`.  
   - Keep it **Public** so GitHub Pages can serve it.

3. **Upload your files**:  
   - On your repository page, click “Add file” → “Upload files”.  
   - Drag & drop `index.html` and `Synthesizers_Guide_to_Angel_Investing.pdf`.  
   - Commit the changes.

4. **Enable GitHub Pages**:  
   - Go to your repository → Settings → Pages.  
   - Under “Branch”, select `main` (or `master`) and `/root`.  
   - Save.  
   - GitHub will give you a live URL, e.g. `https://yourusername.github.io/synthesizer-guide/`.

5. **Visit your page**:  
   - After 1–2 minutes, visit the URL GitHub gave you.  
   - You should see your landing page with the download link working.

## Notes

- If you update `index.html` or the PDF, commit & push the new files and GitHub Pages will update automatically.  
- You can share the GitHub Pages link as your landing page.

---

✅ That’s it! You now have a free hosted landing page + PDF using only GitHub Pages.
